package View;

public class FootballeurView {
    public void afficherStatistiques(int nombreStrategies, int strategiesUtilises, int difference) {
        System.out.println("Statistiques du footballeur :");
        System.out.println("Nombre de stratégies disponibles : " + nombreStrategies);
        System.out.println("Stratégies utilisées : " + strategiesUtilises);
        System.out.println("Différence : " + difference);
    }
}

