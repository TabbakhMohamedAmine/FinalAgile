package View;

public class EquipeView {
    public void afficherStatistiquesEquipe(int totalDifference, int size) {
        System.out.println("Statistiques de l'équipe :");
        System.out.println("Différence totale : " + totalDifference);
        System.out.println("Nombre de footballeurs dans l'équipe : " + size);
    }
}
